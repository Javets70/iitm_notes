--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.18
-- Dumped by pg_dump version 10.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.reviews DROP CONSTRAINT reviews_fk1;
ALTER TABLE ONLY public.reviews DROP CONSTRAINT reviews_fk0;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_fk0;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_fk1;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_fk0;
ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_fk1;
ALTER TABLE ONLY public.orders DROP CONSTRAINT orders_fk0;
ALTER TABLE ONLY public.address DROP CONSTRAINT address_fk0;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_user_name_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT "User_pk";
ALTER TABLE ONLY public.reviews DROP CONSTRAINT "Reviews_pk";
ALTER TABLE ONLY public.product DROP CONSTRAINT "Product_pk";
ALTER TABLE ONLY public.payment DROP CONSTRAINT "Payment_pk";
ALTER TABLE ONLY public.orders DROP CONSTRAINT "Order_pk";
ALTER TABLE ONLY public.categories DROP CONSTRAINT "Categories_pk";
ALTER TABLE ONLY public.address DROP CONSTRAINT "Address_pk";
DROP TABLE public.users;
DROP TABLE public.reviews;
DROP TABLE public.product;
DROP TABLE public.payment;
DROP TABLE public.orders;
DROP TABLE public.categories;
DROP TABLE public.address;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    user_id character varying(20) NOT NULL,
    street_address character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    state character varying(255) NOT NULL,
    pin_code integer NOT NULL,
    country character varying(255) NOT NULL
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    category_id character varying(20) NOT NULL,
    category_name character varying(255) NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id character varying(20) NOT NULL,
    product_id character varying(20) NOT NULL,
    user_id character varying(20) NOT NULL,
    quantity integer NOT NULL,
    date_ordered date NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    payment_id character varying(20) NOT NULL,
    user_id character varying(20) NOT NULL,
    order_id character varying(20) NOT NULL,
    payment_date date NOT NULL,
    amount double precision NOT NULL,
    payment_method character varying(255) NOT NULL
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id character varying(25) NOT NULL,
    category_id character varying(20) NOT NULL,
    product_name character varying(255) NOT NULL,
    price integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    review_id character varying(20) NOT NULL,
    product_id character varying(20) NOT NULL,
    user_id character varying(20) NOT NULL,
    rating integer NOT NULL
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id character varying(20) NOT NULL,
    user_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    mobile_no character varying(20) NOT NULL,
    billing_address character varying(255) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (user_id, street_address, city, state, pin_code, country) FROM stdin;
\.
COPY public.address (user_id, street_address, city, state, pin_code, country) FROM '$$PATH$$/2845.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (category_id, category_name) FROM stdin;
\.
COPY public.categories (category_id, category_name) FROM '$$PATH$$/2846.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, product_id, user_id, quantity, date_ordered) FROM stdin;
\.
COPY public.orders (order_id, product_id, user_id, quantity, date_ordered) FROM '$$PATH$$/2843.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (payment_id, user_id, order_id, payment_date, amount, payment_method) FROM stdin;
\.
COPY public.payment (payment_id, user_id, order_id, payment_date, amount, payment_method) FROM '$$PATH$$/2844.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, category_id, product_name, price, quantity) FROM stdin;
\.
COPY public.product (product_id, category_id, product_name, price, quantity) FROM '$$PATH$$/2842.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (review_id, product_id, user_id, rating) FROM stdin;
\.
COPY public.reviews (review_id, product_id, user_id, rating) FROM '$$PATH$$/2847.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, user_name, email, mobile_no, billing_address) FROM stdin;
\.
COPY public.users (user_id, user_name, email, mobile_no, billing_address) FROM '$$PATH$$/2841.dat';

--
-- Name: address Address_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT "Address_pk" PRIMARY KEY (user_id);


--
-- Name: categories Categories_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "Categories_pk" PRIMARY KEY (category_id);


--
-- Name: orders Order_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "Order_pk" PRIMARY KEY (order_id);


--
-- Name: payment Payment_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT "Payment_pk" PRIMARY KEY (payment_id);


--
-- Name: product Product_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT "Product_pk" PRIMARY KEY (product_id);


--
-- Name: reviews Reviews_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "Reviews_pk" PRIMARY KEY (review_id);


--
-- Name: users User_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "User_pk" PRIMARY KEY (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_user_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_name_key UNIQUE (user_name);


--
-- Name: address address_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_fk0 FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: orders orders_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_fk0 FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: orders orders_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_fk1 FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: payment payment_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_fk0 FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: payment payment_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_fk1 FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: product product_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_fk0 FOREIGN KEY (category_id) REFERENCES public.categories(category_id);


--
-- Name: reviews reviews_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_fk0 FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: reviews reviews_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_fk1 FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

